package kr.kwangan2.springbootboard.member.service;

import kr.kwangan2.springbootboard.member.entity.Member;

public interface MemberService {
	
	Member getMember(Member member);

}
