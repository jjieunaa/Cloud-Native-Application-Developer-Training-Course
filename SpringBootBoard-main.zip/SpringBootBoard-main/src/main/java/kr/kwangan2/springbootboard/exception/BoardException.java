package kr.kwangan2.springbootboard.exception;

public class BoardException extends RuntimeException {
	
	public BoardException(String message) {
		super(message);
	}

}
