package kr.kwangan2.springbootboard.exception;

public class BoardNotFoundException extends BoardException {
	
	public BoardNotFoundException(String message) {
		super(message);
	}

}
